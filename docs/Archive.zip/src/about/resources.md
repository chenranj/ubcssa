# 资源下载

| **文件名** | 下载链接                   |
| ------------------------------------------- | ------------------------------------------------------------ |
| **新冠健康包分发报告** | [查看PDF](https://ubcssa.org/safe_report)                   |
| **By Law 章程** （2021）                         | [查看PDF](https://ubcssa.org/by-law.pdf) |
| **Logo Assets**                             | [下载zip](https://ubcssa.org/logo.zip) |