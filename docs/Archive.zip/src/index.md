---
home: true
heroImage: https://ubcssa.org/logo.png
tagline: 纽约州立大学布法罗分校中国学生学者联合会
footer: UBCSSA © 2021
---

<div style="text-align: center">
   <Bit/>
 </div>

 <div class="features">
   <div class="feature">
     <h2>学校更新安全指导方针</h2>
     <p>学校官方指定了2022年春季学期的安全指导方针，需要学生提交在1月31日前接种的新冠疫苗加强针的证明文件并在返校前提供新冠阴性检测报告。</p>
     <a href=“https://www.buffalo.edu/coronavirus/health-and-safety/health-safety-guidelines.html”>查看详情 ＞</a>
   </div>
 </div>
