纽约州立大学布法罗分校中国学生生活手册（2015 - 2021）

CSSA Handbook for Chinese Students and Scholars at University at Buffalo (2015 - 2021)

Copyright © 2015 - 2021 by Chinese Students and Scholars Association.

University at Buffalo, SUNY

本书由纽约州立大学布法罗分校中国学生学者联合会理事会出版发行。未经编者预先书面许可，任何组织和个人不得以任何方式抄袭或转载本书的任何部分。版权所有，侵权必究。

All right reserved. No part of this book maybe reproduced, in any form or by an means, without permission in writing from publisher.

All trademarks, service marks, registered trademarks, and registered service marks are the property of their respective owners and are used herein for identification purposes only.

Chinese Students & Scholars Association, University at Buffalo (SUNY)

376 Student Union, University at Buffalo, Buffalo, NY 14260-2100, U.S.A

Digital Only

2021年 - 第七版

7th edition - 2021



If you have something (mistake, advice, copyright, etc.) to tell us, please send an email to [buffalocssa@gmail.com](mailto:buffalocssa@gmail.com).

请发送邮件至[buffalocssa@gmail.com](mailto:buffalocssa@gmail.com)和我们取得联系（内容包括但不局限于疏漏、建议、版权等事宜）。



**主编：金琛然、吴沂泽、姬妤人、朱亦君**

**编委：金琛然、吴沂泽、姬妤人、朱亦君、吕顺顺、汪佩然、Michael、曹怡帆、方锦帆、汪屹天**

**网页：钟梓榆、励景松、金琛然**

**媒体：吴沂泽**
